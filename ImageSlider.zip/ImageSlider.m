objects=imaqfind;
delete(objects)
v=videoinput('winvideo',1);
preview(v);  
set(v,'ReturnedColorspace','rgb');
l=0;
r=0;
slide=1;
for i=1:10
img=getsnapshot(v);
end
bg=img;
bg=rgb2gray(bg);
y=strcat('pic',num2str(slide),'.jpg');
figure(4),imshow(y);
for i=1:10000
img=getsnapshot(v);
img=rgb2gray(img);
mt=imsubtract(bg,img); 
[r,c]=size(mt(:,:,1));
for x=1:r
    for y=1:c
        if mt(x,y)>40
            mt(x,y)=255;
        else 
            mt(x,y)=0;
        end
    end
end
count=0;
for x=1:r
    for y=1:c/4
        if mt(x,y)==255;
            count=count+1;
        end
    end
end
if count>30000
   l=l+1;
   if l>10
      if slide==1
          disp('First Image');
      else
          slide=slide-1;
          y=strcat('pic',num2str(slide),'.jpg');
          figure(4),imshow(y);
          pause(2);
      end
      
      l=0;
   end
end

count=sum(double(mt(:,3*c/4:end)));
if count>30000
    r=r+1;
    if r>10
      if slide==6
          disp('Last Image');
      else
          slide=slide+1;
          y=strcat('pic',num2str(slide),'.jpg');
          figure(4),imshow(y);
          pause(2);
      end
      r=0;
    end;
end
end